//
//  ViewController.swift
//  UIRefreshConrtolDemo
//
//  Created by Quinn on 2019/1/7.
//  Copyright © 2019 Quinn. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    

}

extension ViewController:

